# E-commerce Async XHR

Este projeto demonstra o uso de **XMLHttpRequest** para processamento assíncrono em um e-commerce.

## Estrutura
- `src/js/utils/xhr.js`: Funções utilitárias para requisições assíncronas.
- `src/js/home.js`: Exemplo de uso na página inicial.
- `index.html`: Página inicial simples.

## Como rodar
Basta abrir `index.html` em um navegador compatível.

---
Projeto criado para fins acadêmicos (AOP3 - Desenvolvimento Web Back End).
